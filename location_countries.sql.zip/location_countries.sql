-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 15, 2015 at 04:51 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `quest`
--

-- --------------------------------------------------------

--
-- Table structure for table `location_countries`
--

CREATE TABLE IF NOT EXISTS `location_countries` (
`id` int(10) unsigned NOT NULL,
  `code` varchar(5) DEFAULT NULL,
  `name` varchar(150) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=235 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `location_countries`
--

INSERT INTO `location_countries` (`id`, `code`, `name`) VALUES
(1, 'AD', 'Andorra'),
(2, 'AE', 'United Arab Emirates'),
(3, 'AF', 'Afghanistan'),
(4, 'AG', 'Antigua And Barbuda'),
(5, 'AI', 'Anguilla'),
(6, 'AL', 'Albania'),
(7, 'AM', 'Armenia'),
(9, 'AO', 'Angola'),
(10, 'AR', 'Argentina'),
(11, 'AT', 'Austria'),
(12, 'AU', 'Australia'),
(13, 'AW', 'Aruba'),
(14, 'AZ', 'Azerbaijan'),
(15, 'BA', 'Bosnia And Herzegovina'),
(16, 'BB', 'Barbados'),
(17, 'BD', 'Bangladesh'),
(18, 'BE', 'Belgium'),
(19, 'BF', 'Burkina Faso'),
(20, 'BG', 'Bulgaria'),
(21, 'BH', 'Bahrain'),
(22, 'BI', 'Burundi'),
(23, 'BJ', 'Benin'),
(24, 'BM', 'Bermuda'),
(25, 'BN', 'Brunei Darussalam'),
(26, 'BO', 'Bolivia'),
(27, 'BR', 'Brazil'),
(28, 'BS', 'Bahamas'),
(29, 'BT', 'Bhutan'),
(30, 'BW', 'Botswana'),
(31, 'BY', 'Belarus'),
(32, 'BZ', 'Belize'),
(33, 'CA', 'Canada'),
(34, 'CC', 'Cocos (Keeling) Islands'),
(35, 'CD', 'Congo, The Democratic Republic Of The'),
(36, 'CF', 'Central African Republic'),
(37, 'CG', 'Congo'),
(38, 'CH', 'Switzerland'),
(39, 'CI', 'Cote D''ivoire'),
(40, 'CK', 'Cook Islands'),
(41, 'CL', 'Chile'),
(42, 'CM', 'Cameroon'),
(43, 'CN', 'China'),
(44, 'CO', 'Colombia'),
(45, 'CR', 'Costa Rica'),
(46, 'CU', 'Cuba'),
(47, 'CV', 'Cape Verde'),
(48, 'CX', 'Christmas Island'),
(49, 'CY', 'Cyprus'),
(50, 'CZ', 'Czech Republic'),
(51, 'DE', 'Germany'),
(52, 'DJ', 'Djibouti'),
(53, 'DK', 'Denmark'),
(54, 'DM', 'Dominica'),
(55, 'DO', 'Dominican Republic'),
(56, 'DZ', 'Algeria'),
(57, 'EC', 'Ecuador'),
(58, 'EE', 'Estonia'),
(59, 'EG', 'Egypt'),
(60, 'EH', 'Western Sahara'),
(61, 'ER', 'Eritrea'),
(62, 'ES', 'Spain'),
(63, 'ET', 'Ethiopia'),
(64, 'FI', 'Finland'),
(65, 'FJ', 'Fiji'),
(66, 'FK', 'Falkland Islands (Malvinas)'),
(67, 'FM', 'Micronesia, Federated States Of'),
(68, 'FO', 'Faroe Islands'),
(69, 'FR', 'France'),
(70, 'GA', 'Gabon'),
(71, 'GB', 'United Kingdom'),
(72, 'GD', 'Grenada'),
(73, 'GE', 'Georgia'),
(74, 'GF', 'French Guiana'),
(75, 'GG', 'Guernsey'),
(76, 'GH', 'Ghana'),
(77, 'GI', 'Gibraltar'),
(78, 'GL', 'Greenland'),
(79, 'GM', 'Gambia'),
(80, 'GN', 'Guinea'),
(81, 'GP', 'Guadeloupe'),
(82, 'GQ', 'Equatorial Guinea'),
(83, 'GR', 'Greece'),
(84, 'GS', 'South Georgia And The South Sandwich Islands'),
(85, 'GT', 'Guatemala'),
(86, 'GW', 'Guinea-Bissau'),
(87, 'GY', 'Guyana'),
(88, 'HK', 'Hong Kong'),
(89, 'HN', 'Honduras'),
(90, 'HR', 'Croatia'),
(91, 'HT', 'Haiti'),
(92, 'HU', 'Hungary'),
(93, 'ID', 'Indonesia'),
(94, 'IE', 'Ireland'),
(95, 'IL', 'Israel'),
(96, 'IM', 'Isle Of Man'),
(97, 'IN', 'India'),
(98, 'IQ', 'Iraq'),
(99, 'IR', 'Iran, Islamic Republic Of'),
(100, 'IS', 'Iceland'),
(101, 'IT', 'Italy'),
(102, 'JE', 'Jersey'),
(103, 'JM', 'Jamaica'),
(104, 'JO', 'Jordan'),
(105, 'JP', 'Japan'),
(106, 'KE', 'Kenya'),
(107, 'KG', 'Kyrgyzstan'),
(108, 'KH', 'Cambodia'),
(109, 'KI', 'Kiribati'),
(110, 'KM', 'Comoros'),
(111, 'KN', 'Saint Kitts And Nevis'),
(112, 'KP', 'Korea, Democratic People''s Republic Of'),
(113, 'KR', 'Korea, Republic Of'),
(114, 'KW', 'Kuwait'),
(115, 'KY', 'Cayman Islands'),
(116, 'KZ', 'Kazakhstan'),
(117, 'LA', 'Lao People''s Democratic Republic'),
(118, 'LB', 'Lebanon'),
(119, 'LC', 'Saint Lucia'),
(120, 'LI', 'Liechtenstein'),
(121, 'LK', 'Sri Lanka'),
(122, 'LR', 'Liberia'),
(123, 'LS', 'Lesotho'),
(124, 'LT', 'Lithuania'),
(125, 'LU', 'Luxembourg'),
(126, 'LV', 'Latvia'),
(127, 'LY', 'Libyan Arab Jamahiriya'),
(128, 'MA', 'Morocco'),
(129, 'MC', 'Monaco'),
(130, 'MD', 'Moldova, Republic Of'),
(131, 'ME', 'Montenegro'),
(132, 'MG', 'Madagascar'),
(133, 'MH', 'Marshall Islands'),
(134, 'MK', 'Macedonia'),
(135, 'ML', 'Mali'),
(136, 'MM', 'Myanmar'),
(137, 'MN', 'Mongolia'),
(138, 'MO', 'Macao'),
(139, 'MP', 'Northern Mariana Islands'),
(140, 'MQ', 'Martinique'),
(141, 'MR', 'Mauritania'),
(142, 'MS', 'Montserrat'),
(143, 'MT', 'Malta'),
(144, 'MU', 'Mauritius'),
(145, 'MV', 'Maldives'),
(146, 'MW', 'Malawi'),
(147, 'MX', 'Mexico'),
(148, 'MY', 'Malaysia'),
(149, 'MZ', 'Mozambique'),
(150, 'NA', 'Namibia'),
(151, 'NC', 'New Caledonia'),
(152, 'NE', 'Niger'),
(153, 'NF', 'Norfolk Island'),
(154, 'NG', 'Nigeria'),
(155, 'NI', 'Nicaragua'),
(156, 'NL', 'Netherlands'),
(157, 'NO', 'Norway'),
(158, 'NP', 'Nepal'),
(159, 'NR', 'Nauru'),
(160, 'NU', 'Niue'),
(161, 'NZ', 'New Zealand'),
(162, 'OM', 'Oman'),
(163, 'PA', 'Panama'),
(164, 'PE', 'Peru'),
(165, 'PF', 'French Polynesia'),
(166, 'PG', 'Papua New Guinea'),
(167, 'PH', 'Philippines'),
(168, 'PK', 'Pakistan'),
(169, 'PL', 'Poland'),
(170, 'PM', 'Saint Pierre And Miquelon'),
(171, 'PN', 'Pitcairn'),
(172, 'PS', 'Palestinian Territory'),
(173, 'PT', 'Portugal'),
(174, 'PW', 'Palau'),
(175, 'PY', 'Paraguay'),
(176, 'QA', 'Qatar'),
(177, 'RE', 'Reunion'),
(178, 'RO', 'Romania'),
(179, 'RS', 'Serbia'),
(180, 'RU', 'Russian Federation'),
(181, 'RW', 'Rwanda'),
(182, 'SA', 'Saudi Arabia'),
(183, 'SB', 'Solomon Islands'),
(184, 'SC', 'Seychelles'),
(185, 'SD', 'Sudan'),
(186, 'SE', 'Sweden'),
(187, 'SG', 'Singapore'),
(188, 'SH', 'Saint Helena'),
(189, 'SI', 'Slovenia'),
(190, 'SJ', 'Svalbard And Jan Mayen'),
(191, 'SK', 'Slovakia'),
(192, 'SL', 'Sierra Leone'),
(193, 'SM', 'San Marino'),
(194, 'SN', 'Senegal'),
(195, 'SO', 'Somalia'),
(196, 'SR', 'Suriname'),
(197, 'ST', 'Sao Tome And Principe'),
(198, 'SV', 'El Salvador'),
(199, 'SY', 'Syrian Arab Republic'),
(200, 'SZ', 'Swaziland'),
(201, 'TC', 'Turks And Caicos Islands'),
(202, 'TD', 'Chad'),
(203, 'TF', 'French Southern Territories'),
(204, 'TG', 'Togo'),
(205, 'TH', 'Thailand'),
(206, 'TJ', 'Tajikistan'),
(207, 'TK', 'Tokelau'),
(208, 'TM', 'Turkmenistan'),
(209, 'TN', 'Tunisia'),
(210, 'TO', 'Tonga'),
(211, 'TR', 'Turkey'),
(212, 'TT', 'Trinidad And Tobago'),
(213, 'TV', 'Tuvalu'),
(214, 'TW', 'Taiwan'),
(215, 'TZ', 'Tanzania, United Republic Of'),
(216, 'UA', 'Ukraine'),
(217, 'UG', 'Uganda'),
(218, 'US', 'United States'),
(219, 'UY', 'Uruguay'),
(220, 'UZ', 'Uzbekistan'),
(221, 'VC', 'Saint Vincent And The Grenadines'),
(222, 'VE', 'Venezuela'),
(223, 'VG', 'Virgin Islands, British'),
(224, 'VI', 'Virgin Islands, U.S.'),
(225, 'VN', 'Vietnam'),
(226, 'VU', 'Vanuatu'),
(227, 'WF', 'Wallis And Futuna'),
(228, 'WS', 'Samoa'),
(229, 'YE', 'Yemen'),
(230, 'YT', 'Mayotte'),
(231, 'ZA', 'South Africa'),
(232, 'ZM', 'Zambia'),
(234, 'ZW', 'Zimbabwe');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `location_countries`
--
ALTER TABLE `location_countries`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `location_countries`
--
ALTER TABLE `location_countries`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=235;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
